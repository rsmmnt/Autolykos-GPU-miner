#!/bin/bash

cd `dirname $0`

./autolykos-cuda
