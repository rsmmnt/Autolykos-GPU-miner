# Required
# Must be the same as miner's base directory
CUSTOM_NAME=autolykos_cuda

# Optional
# Full path to log file basename. WITHOUT EXTENSION (don't include .log at the end)
# Used to truncate logs and rotate,
# E.g. /var/log/mysuperminer/somelogname (filename without .log at the end)
CUSTOM_LOG_BASENAME=/var/log/miner/$CUSTOM_NAME/$CUSTOM_NAME

CUSTOM_CONFIG_FILENAME=/hive/custom/$CUSTOM_NAME/config.json
# Optional. May be used in miner's config generatino
# API port used to collect stats
#MINER_API_PORT=60050

# Optional
# If miner has configurable fork this should define default
#MINER_DEFAULT_FORK=legacy

# Required
# Should be set to the latest version of miner which you have implemented
CUSTOM_VERSION=0.0.1


# Optional
# If miner required libcurl3 compatible lib you can enable this
LIBCURL3_COMPAT=0