# Returns the version which is running now.
function miner_ver() {
	echo $CUSTOM_VERSION
}


# Outputs generated config file
function miner_config_echo() {
	local MINER_VER=`0.0.1`
	miner_echo_config_file "/hive/miners/custom/$CUSTOM_NAME/config.json"
}

# Generates config file
function miner_config_gen() {
	local MINER_CONFIG="$CUSTOM_NAME/config.json"
	mkfile_from_symlink $MINER_CONFIG

	conf=`cat $MINER_DIR/config.json | envsubst`
	#...

	echo -e "$conf" > $MINER_CONFIG
}